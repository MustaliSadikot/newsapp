import React, { useEffect, useState } from "react";
import Card from "./Card";
import LoadingBar from 'react-top-loading-bar';

function Title(props) {
  const [progress, setProgress] = useState(0)
  const [articles,updatenews] = useState([])

  const mode = props.mode;
  const news = props.news;

  const getnews =async()=>{
    setProgress(25)
    const data1 = await fetch(`https://newsapi.org/v2/top-headlines?category=${props.category}&country=in&apiKey=7b70d77664df475498ac9a68f0dd75bf`);
    setProgress(50)
    const paraseData = await data1.json();
    setProgress(70)
    console.log(paraseData);
    updatenews(paraseData.articles);
    setProgress(100)
  }

  useEffect(() => {
    getnews()
  }, [props.category])
  
  return (
    <>
         <LoadingBar
        color={!mode ? "#EBE834" : "#0B5ED7"}
        progress={progress}
        height={5}
        onLoaderFinished={() => setProgress(0)}
      />
     
      <h1 className={`text-center mt-4 mb-5 text-${mode ? "dark" : "light"} text-decoration-underline`}>
        DailyNews - {props.category.charAt(0).toUpperCase()+props.category.slice(1)} Headlines
      </h1>
      <div className="container">

        <div className={`row row-cols-1 row-cols-md-2 g-4`}>
         {articles.map((element,index)=>{
          return <Card mode={mode} news={element}/>
        })}
        
        </div>
      </div>
    </>
  );
}

export default Title;
