import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Title from './components/Title';
import Card from './components/Card';
import { useState } from 'react';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';


function App() {

  const [mode,updatemode] = useState(true);

  const changemode = () => {
    updatemode(!mode);
    // console.log(mode);
  };

  document.body.style.backgroundColor = mode
  ? "#ffffff"
  : "#2C3333"; /*"#292b2c"*/
  return (
    <>

    <Router>
    <Navbar bar={changemode} mode={mode}></Navbar>
      <Routes>
        <Route path="/" element={<Title mode={mode} category="general" heading="General"></Title>}></Route>
        <Route path="/entertainment" element={<Title mode={mode} category="entertainment" heading="Entertainment"></Title>}></Route>
        <Route path="/general" element={<Title mode={mode} category="general" heading="General"></Title>}></Route>
        <Route path="/science" element={<Title mode={mode} category="science" heading="Science"></Title>}></Route>
        <Route path="/sports" element={<Title mode={mode} category="sports" heading="Sports"></Title>}></Route>
        <Route path="/health" element={<Title mode={mode} category="health" heading="Health"></Title>}></Route>
        <Route path="/business" element={<Title mode={mode} category="business" heading="Business"></Title>}></Route>
      </Routes>

    </Router>
   
    

    </>
  );
}

export default App;
